/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "Parameters.h"
#include "PreAmp.h"
#include "CleanAmp.h"
#include "HighGain.h"
#include "Delay.h"
#include "Chorus.h"
#include "Reverb.h"
#include "JsonSerializer.h"
#include "Measurement.h"
#include "EQModule.h"

//==============================================================================
/**
*/
class DownfallPluginAudioProcessor  : public juce::AudioProcessor
{
public:
    //==============================================================================
    DownfallPluginAudioProcessor();
    ~DownfallPluginAudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorParameter* getBypassParameter() const override;

    void setIRToConvolution(juce::File newIRFile);

    Measurement outputLevelL, outputLevelR, inputLevelL, inputLevelR;
    parameters::Parameters parameters{ *this };

private:
    juce::SmoothedValue<float> inputGainSmoother;
    juce::SmoothedValue<float> outputGainSmoother;

    std::unique_ptr<preamp::PreAmpDecorator> preamp;
    std::vector<preamp::PreAmpInterface*> preAmpStrategies{ 2 };

    effects::DelayFX delay;
    effects::ChorusFX chorus;
    effects::ReverbFX reverb{ 100.0 };

    juce::dsp::NoiseGate<float> gate;

    juce::dsp::Convolution convolution;
    EQModule eq;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DownfallPluginAudioProcessor)
};
