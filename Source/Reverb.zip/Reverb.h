/*
  ==============================================================================

    Reverb.h
    Created: 21 Mar 2026 1:16:20pm
    Author:  Alberto

  ==============================================================================
*/

#pragma once
#include <JuceHeader.h>
#include "Splitter.h"
#include "Diffuser.h"
#include "Effect.h"

constexpr auto REVERB_CHANNELS = 4u;

namespace effects {
    class ReverbFX : public FX {
    public:
        ReverbFX();
        void prepare(juce::dsp::ProcessSpec& spec) override;
        void update(parameters::FXParameters& parameters) override;
        void process(juce::dsp::ProcessContextReplacing<float>& context) override;
        void reset() override;

    private:
        std::array<float, REVERB_CHANNELS> delayTimes{ 31.f, 37.f, 41.f, 43.f };

        Splitter split;
        Diffuser diffuser;
        std::array<juce::dsp::DelayLine<float>, REVERB_CHANNELS> delays;
        std::array<float, REVERB_CHANNELS> feedbacks;
        juce::dsp::StateVariableTPTFilter<float> highCutFilter; //low-pass filter

        juce::SmoothedValue<float> decay;
        juce::SmoothedValue<float> mix;
    };
}