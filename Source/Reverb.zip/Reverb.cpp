/*
  ==============================================================================

    Reverb.cpp
    Created: 21 Mar 2026 1:16:20pm
    Author:  Alberto

  ==============================================================================
*/

#include "Reverb.h"

effects::ReverbFX::ReverbFX(float _delayTime)
{
    delayTime = _delayTime;
}

void effects::ReverbFX::prepare(juce::dsp::ProcessSpec& spec)
{
    split.prepare(spec.maximumBlockSize);
    for (int i = 0; i < DIFF_STEPS; ++i) {
        diff[i].prepare(spec);
    }

    juce::dsp::ProcessSpec oneChannelSpec;
    oneChannelSpec.maximumBlockSize = spec.maximumBlockSize;
    oneChannelSpec.numChannels = 1;
    oneChannelSpec.sampleRate = spec.sampleRate;

    float delaySamplesBase = delayTime / 1000.0f * spec.sampleRate;
    for (int i = 0; i < REVERB_CHANNELS; ++i) {
        auto& delayLine = delays[i];
        delayLine.reset();
        delayLine.prepare(oneChannelSpec);

        float r = i / delaySamplesBase;
        float delayInSamples = (float) std::pow(2, r) * delaySamplesBase;

        delayLine.setDelay(std::ceilf(delayInSamples));
        delayedSamples[i] = 0.f;
    }

    decay.reset(0.002f);
    decay.setCurrentAndTargetValue(0.f);

    mix.reset(0.002f);
    mix.setCurrentAndTargetValue(0.5f);

    
}

void effects::ReverbFX::update(parameters::FXParameters& parameters)
{
    bypass = parameters.getBypassEffect().get();

    parameters::ReverbParameters& reverbParams = dynamic_cast<parameters::ReverbParameters&>(parameters);
    decay.setTargetValue(reverbParams.getDecay().get() / 100.f);
    mix.setTargetValue(reverbParams.getMix().get() / 100.f);
}

void effects::ReverbFX::process(juce::dsp::ProcessContextReplacing<float>& context)
{
    if (bypass)
        return;

    split.split(context);
    for (int i = 0; i < DIFF_STEPS; ++i) {
        diff[i].process(split);
    }

    for (int c = 0; c < REVERB_CHANNELS; ++c) {
        output[c] = split.getAudioBuffer(c).getWritePointer(0);
        jassert(output[c] != nullptr);
        delayedSamples[c] = 0.f;
    }
    
    for (int sample = 0; sample < split.getAudioBuffer(0).getNumSamples(); ++sample) {
        /*for (int c = 0; c < REVERB_CHANNELS; ++c) {
            delayedSamples[c] = delays[c].popSample(0);
        }
        Householder(delayedSamples);
        for (int c = 0; c < REVERB_CHANNELS; ++c) {
            float mixedValue = delayedSamples[c] * decay.getNextValue();
            float sum = output[c][sample] + mixedValue * mix.getNextValue();
            delays[c].pushSample(0, sum);
            output[c][sample] = sum;
        }*/

        float left = 0.f;
        float right = 0.f;
        for (int c = 0; c < REVERB_CHANNELS; c += 2) {
            left += output[c][sample];
            right += output[c + 1][sample];
        }

        auto& outputBlock = context.getOutputBlock();
        float scaling = (float) outputBlock.getNumChannels() / (float) REVERB_CHANNELS;
        if (outputBlock.getNumChannels() > 1) {
            float* outL = outputBlock.getChannelPointer(0);
            float* outR = outputBlock.getChannelPointer(1);
            outL[sample] = left * scaling;
            outR[sample] = right * scaling;
        }
        else {
            float* outL = outputBlock.getChannelPointer(0);
            outL[sample] = left * scaling;
        }
    }
}

void effects::ReverbFX::reset()
{
    split.clearAudioBuffers();
    for (int i = 0; i < REVERB_CHANNELS; ++i) {
        delayedSamples[i] = 0.f;
        delays[i].reset();
    }
    for (int i = 0; i < DIFF_STEPS; ++i) {
        diff[i].reset();
    }
}

void effects::ReverbFX::Householder(std::array<float, REVERB_CHANNELS>& inputs)
{
    float sum = 0.f;
    for (int c = 0; c < REVERB_CHANNELS; ++c) {
        sum += inputs[c];
    }
    sum *= multiplier;
    for (int c = 0; c < REVERB_CHANNELS; ++c) {
        inputs[c] += sum;
    }
}
